<?php
/**
 * Deprecated: class is automatically loaded anyway
 */
WPML_Root_Page::init();